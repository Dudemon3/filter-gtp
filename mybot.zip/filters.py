from pyrogram import Client, filters
from config import ADMINS
from database import add_filter, get_filters, delete_filter, delete_all_filters
from utils import parse_buttons

@Client.on_message(filters.command("filter") & filters.private)
async def add_filter_private(client, message):
    if message.from_user.id not in ADMINS:
        return await message.reply("You are not authorized.")

    await message.reply("Send me the keyword for the filter:")

    keyword = (await client.listen(message.chat.id)).text
    await message.reply(f"Send the reply text for `{keyword}` (you can also add buttons like `Button Text | https://link`)")

    reply = await client.listen(message.chat.id)
    text = reply.text
    reply_text, buttons = text.splitlines()[0], parse_buttons("\n".join(text.splitlines()[1:]))

    await add_filter(message.chat.id, keyword.lower(), reply_text, buttons)
    await message.reply(f"Filter for `{keyword}` saved successfully!")

@Client.on_message(filters.command("filters"))
async def list_filters(client, message):
    filters_list = await get_filters(message.chat.id)
    if not filters_list:
        return await message.reply("No filters available.")
    
    msg = "**Available Filters:**\n\n"
    for f in filters_list:
        msg += f"• `{f['keyword']}`\n"
    await message.reply(msg)

@Client.on_message(filters.command("del"))
async def delete_single_filter(client, message):
    if message.from_user.id not in ADMINS:
        return await message.reply("You are not authorized.")
    
    if len(message.command) < 2:
        return await message.reply("Usage: `/del keyword`")
    
    keyword = message.command[1].lower()
    await delete_filter(message.chat.id, keyword)
    await message.reply(f"Deleted filter `{keyword}`.")

@Client.on_message(filters.command("delall"))
async def delete_all(client, message):
    if message.from_user.id not in ADMINS:
        return await message.reply("You are not authorized.")
    
    await delete_all_filters(message.chat.id)
    await message.reply("Deleted all filters!")
