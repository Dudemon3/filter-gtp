from motor.motor_asyncio import AsyncIOMotorClient
from config import MONGO_URI

client = AsyncIOMotorClient(MONGO_URI)
db = client.filters_db
filters_col = db.filters

async def add_filter(chat_id, keyword, reply_text, buttons=None):
    await filters_col.update_one(
        {"chat_id": chat_id, "keyword": keyword},
        {"$set": {"reply_text": reply_text, "buttons": buttons}},
        upsert=True
    )

async def get_filters(chat_id):
    return await filters_col.find({"chat_id": chat_id}).to_list(length=None)

async def delete_filter(chat_id, keyword):
    await filters_col.delete_one({"chat_id": chat_id, "keyword": keyword})

async def delete_all_filters(chat_id):
    await filters_col.delete_many({"chat_id": chat_id})
