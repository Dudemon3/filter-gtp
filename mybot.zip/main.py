from pyrogram import Client
import filters
from config import BOT_TOKEN, API_ID, API_HASH

app = Client(
    "mybot",
    bot_token=BOT_TOKEN,
    api_id=API_ID,
    api_hash=API_HASH
)

if __name__ == "__main__":
    print("Bot Started Successfully!")
    app.run()
