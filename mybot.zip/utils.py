from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

def parse_buttons(text):
    buttons = []
    lines = text.splitlines()
    for line in lines:
        if '|' in line:
            parts = line.split('|')
            button_text = parts[0].strip()
            button_url = parts[1].strip()
            buttons.append([InlineKeyboardButton(button_text, url=button_url)])
    return InlineKeyboardMarkup(buttons) if buttons else None
